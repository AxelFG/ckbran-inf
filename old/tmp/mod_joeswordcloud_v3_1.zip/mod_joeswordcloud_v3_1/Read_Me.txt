Language:	English
Platform:	Joomla 3.2.1
Author:		J. Lipman (info@joellipman.com)
Website:	www.joellipman.com
Copyright:	Copyright (C) 2014 Joellipman.Com
License:	GNU/GPL http://www.gnu.org/licenses/gpl-3.0.html

Extension:	Joes Word Cloud
Name:		mod_joeswordcloud
Type:		Joomla 3.0+ Module
Version:	3.1
Created:	10/09/2010
Updated:	15/01/2014


Script Function:
This extension is a joomla module displaying the words from your Joomla! core articles and displays them in a "cloud" of words displayed in a module. Font-size depends on the frequency of the word throughout your articles.

What makes this word cloud module different is that it takes its words directly from your Joomla! core articles instead of your meta tags which means less work to setup. It has been tested with various languages across the world and 3rd-party templates.

I wanted a module that doesn't need meta tags to be setup for it. I want a module which quickly installs and can work as is. I've even added some CSS styling options because I'm that lazy.

It's free as always, so enjoy!

Note:
For Joomla! 1.5.x websites, please visit my downloads page for the previous version of this module.


Tested on:
- Joomla v3.2
- PHP v5.3.1
- MySQL v5.1.30


Admin Parameters include:
+ module class suffix
+ module width
+ text alignment
+ underline override
+ background to each word
+ background text color
+ background color
+ background border color
+ background size
+ rounded backgrounds (css3 only)
------------------------
+ get words from title or introtext or both
+ scan displayed article only
+ use access levels (1.6.x+)
+ keyword inclusion list
+ keyword exclusion list
+ case-sensitive option
+ from category
+ include restricted articles
+ include/exclude categories
------------------------
+ search URL can be changed
+ how many words to display
+ minimum word length
+ minimum font size (range)
+ maximum font size (range)
+ order words by
+ order words
------------------------
+ include "K2" content
+ include "Hot Property" content
+ include "Phoca Download" content
+ include "jEvents" content
+ EXCLUDE "Joomla" content
------------------------
+ display debug mode
+ display Powered By


ChangeLog:

v3.1 (15/01/2014)
- Fixed Bug: German language support.

v3 (19/09/2013)
- Fixed Bug: Hardcoded DS value for Joomla 3.x compatibility.

v2.2 (16/05/2013)
- Enhancement: Parameter: If viewing an article, scan Displayed Article Only
- Enhancement: Code Reduction (Removed unnecessary debug notes)
- Enhancement: Code Optimization
- Critical: Fix for combination of 3rd-Party Integration and User Access Levels

v2.1.1 (11/05/2013)
- Enhancement: Parameter: Display Debug Mode (was "display SQL query")
- Enhancement: Debug Mode: Check List
- Enhancement: Integration: Exclude Joomla Articles.

v2.1 (05/05/2013)
- Enhancement: Debug Mode: Check List
- Enhancement: Code Optimization
- Enhancement: Integration: Include jEvents.

v2.0.0 (07/12/2012)
- Checked for compatibility with Joomla v2.5.x
- Enhancement: SearchURL is html decoded/encoded for W3C Validation
- Bug Fix: Line-height is adjusted to font-size
- Removed jEvents integration

v1.6.8 (27/10/2011)
- Enhancement: Integration: Include jEvents.
- Bug Fix: Inclusion List now displays words in different sizes.

v1.6.7 (08/08/2011)
- Bug Fix: Removed use of Joomla Core db->nameQuote function for old MySQL.
- Enhancement: Check for W3C Validation and force fix "&amp;amp;".
- Double-check that unicode characters work in exclusion list. (they do)

v1.6.6 (20/07/2011)
- Bug Fix: "Case-sensitive=No" now checks that word in different case is not already in list.

v1.6.5 (18/07/2011 - 33 downloads)
- Bug Fix: Keyword Exclusion List removes spaces before and after all words.

v1.6.4 (13/06/2011)
- Added Joomla! Admin Option: Module Content Caching
- Added Joomla! Admin Option: Include content based on User Level
- Added Joomla! Admin Option: Include Category IDs
- Added Joomla! Admin Option: Exclude Category IDs
- Added Joomla! Admin Option: Sort Words By (shuffle, alphabet, frequency)
- Added Joomla! Admin Option: Sort Words Order (ascending, descending)
- Prefixed language file references with JWC to avoid conflicts with 3rd-party apps.
- Restructured extension into an MVC model (fixes H3 and Module Class Suffix issues)
- Removed Joomla! Admin Option: Content Database Length

v1.6.3 (14/05/2011 - 3469 downloads)
- Core script reverted to v1.5.2
- Styled Joomla! Admin Options into sliding panels.
- Added Joomla! Admin Option: Specify border color for link.
- Now checks if mb_strtolower function exists (regresses to strtolower).
- Additional parameters (eg. Word Background) do not load if not enabled.
- Added Joomla! Admin Option: Module width.
- Corrected division by zero if no words found (?) sets to 1.
- Now includes absolute path for word link (JURL::base()).

v1.6.2 (14/03/2011)
- Modified core script for PHP4 compatibility.

v1.6.1 (06/03/2011)
- Re-arranged Joomla! Admin Options.
- Added Joomla! Admin Option: Specify length of database content.
- Added Joomla! Admin Option: Display rounded background color for words.
- Added Joomla! Admin Option: Specify background color for word
- Added Joomla! Admin Option: Specify foreground color for word
- Added Joomla! Admin Option: Specify corner radius for word background

v1.6.0 (02/02/2011)
- Upgraded to work with Joomla 1.6

-----------------------------------------------------------------------------
VERSIONS 1.6.X ARE VALID FOR JOOMLA! 1.6.0 ONLY
VERSIONS 1.5.X ARE RELEASED IN TANDEM AND DEVELOPED SEPARATELY (for continued support for Joomla 1.5 websites)
-----------------------------------------------------------------------------

v1.5.3 (27/06/2011)
- Downgraded Module version 1.6.4 to work with Joomla 1.5.x websites.
- All additions from v1.6.0 to 1.6.4 included in this version.

v1.5.2 (09/04/2011 - 6915 downloads)
- Modified core script for PHP4 compatibility:
- - Replaced mb_strtolower with LOWER...
- Modified core script for performance.
- - Reduced 3 functions into one (strip_punctuation and strip_symbols)
- - Omit words of minimum length and don't index
- Re-fixed module class suffix parameter ???
- Reworded "Display SQL Query" to "Debug Mode"
- - Added word frequency count checker in debug mode

v1.5.1 (14/03/2011)
- Modified core script for PHP4 compatibility.
- Functions for stripping keywords merged into one.

v1.5.0 (11/01/2011)
- Merged all queries for checking 3rd-party content into one SQL query.
- Added Joomla! Admin Option: Display SQL query sent to Database.
- Added Joomla! Admin Option: Case-sensitive (for Cyrillic support).

v1.4.2 (04/01/2011)
- Added Joomla! Admin Option: Include Phoca Download text
- Exclusion list is now case-sensitive (for International character support).
- Fixed bug [TBC]: compilation failed for servers not supporting international characters.
- Fixed bug [TBC]: replaced string formatting foreach statements with legacy FOR statements.

v1.4.1 (17/12/2010)
- Fixed compatibility with PHP v4 ("foreach &value" adapted)

v1.4 (14/12/2010)
- Added Joomla! Admin Option: Keyword Inclusion List
- Fixed bug: Certain templates did not apply the CSS to the module title.
- Removed Joomla! Admin Option: Code Override
- Removed Joomla! Admin Option: Cached-Mode
- Amended Font-size to base on number of words available.

v1.3 (11/11/2010)
- Added Joomla! Admin Option: Keyword Exclusion List
- Added Joomla! Admin Option: Include content K2, Hot Property.
- Added Joomla! Admin Option: Force no underlines on words.

v1.2.3 (28/10/2010)
- Fixed bug: counts international characters rather than bytes.
- Fixed bug: renamed functions so as not to conflict with any pre-existing ones (eg. utf8_strlen)

v1.2.2 (25/10/2010 - 152 downloads)
- Corrected PHP code to work in earlier PHP versions.
- Fixed bug: could not see Hebrew text.
- Fixed bug: refer to $fulltext variable which is now obsolete.

v1.2.1 (25/10/2010 - 14 downloads)
- Removed some word OTT extraction functions (eg. applet, map, object, etc).

v1.2 (21/10/2010)
- Fixed compatibility with UTF8 (International) languages. But broke something else...
- Added requirement to only take words from Published articles.

v1.1 (20/09/2010 - 436 downloads)
- Added Joomla Admin Panel option: Cache-mode

v1.0 (10/09/2010)
- Added Joomla Admin Panel option: Scan Joomla! articles
- Added Joomla Admin Panel option: Scan K2 articles


License Details:
This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,	but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program.  If not, see <http://www.gnu.org/licenses/>.


Thank You:
- Topo for Slovak debugging.
- Michael for suggesting the exclusion list.
- Uri for Hebrew debugging.
- Chris for Russian debugging and suggesting Hot Property (and confirmed this works).
- Hans for suggesting the inclusion list.
- Lisa G. for compatibility with RocketTheme templates and the Gantry framework.
- Miguel C. for module class suffix testing.
- Ronald for compatibility with PHP4.
- Fedor for uppercase/lowercase cyrillic exclusion list.
- Rene and Chris for requesting to exclude categories.
- Martine M. for suggesting word sorting.
- Cedric A. for the cache feature (Thanks for the code) in the admin panel.
- Patrick for suggesting article exclusion if restricted content.


Frequently Asked Questions:



Future Considerations:
- Add Joomla! Admin Option: Remove symbols/punctuation (yes/no).
- Add Joomla! Admin Option: Maximum word length.
- For English language websites with no requirement for UTF8 and no criteria specified, Release v1.00 again.


Any suggestions?  Send them to info@joellipman.com
